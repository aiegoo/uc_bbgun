#include "pin.h"

//StepMotor
int stepCount = 0;              //6카운팅 변수
int stepsPerRevolution = 533;   //분주 값

//Function 선언
void checkShotting();
void shottingPlaySet();
void shottingPlayMode(int stateCase);
void rotationTest(int rotationCase);
void mainMotor(int stepCase);
void mainMotorRev();
void stepMotor(int angle);
void shottingPlay(int shottingCase);
void FirstServoMotor(int servoCase);
void SecondServoMotor(int servoCase);
void ShootServo();

//radioControl Data
int radioData[3] = {3, 3, 3};   //발사 대기, 단발 연발 , 회전 대기

//Shotting toggle 변수
boolean readyShotting = false;      //발사 준비 전 토글
boolean rotationToggle = false;     //회전 토글
boolean ShottingToggle = false;     //발사 버튼 토글
boolean bulletSingleToggle = false; //단발 발사 토글
boolean bulletMultiToggle = false;  //연발 발사 토글

//bullet
int bulletLocation[7] = {1, 1, 1, 1, 1, 1, 6}; //총구 위치 총알 위치, 총알 남은 숫자
int bulletCount = 0;                           //총알 수
int builletCountLocation = 0;                  //현재 총구 위치

int stepCase = 0;

//RadioControl 신호 Receive
void radioControl_Data() {
  int shottingBulletData = pulseIn(shottingBullet, HIGH);     // 발사버튼
  int shottingModeData = pulseIn(shottingMode, HIGH);         // 모드버튼
//  int shottingRotationData = pulseIn(shottingRotation, HIGH); // 회전버튼
  int shottingRotationData = 0;
//  Serial.print(shottingBulletData);
//  Serial.print(" / ");
//  Serial.print(shottingModeData);
//  Serial.print(" / ");
//  Serial.print(shottingRotationData);
//  Serial.print(" / ");
//  Serial.println();
//  delay(1000);
  if (shottingBulletData >= 1200) {
    radioData[0]  = 1;
  } else if (shottingBulletData < 1200 && shottingBulletData > 0) {
    radioData[0] = 0 ;
  }
  if (shottingModeData < 1100 && shottingModeData > 0) {            //단발
    radioData[1] = 1;  
  } else if (shottingModeData > 1800) {     //연발
    radioData[1] = 2; 
  } else {                                  //대기
    radioData[1] = 0;       
  }
  if (shottingRotationData < 1100 && shottingRotationData > 0) {        //오른쪽 회전
    stepCase = 0;
    radioData[2] = 2;  
  } else if (shottingRotationData > 1800) { //왼쪽 회전
    stepCase = 0;
    radioData[2] = 1;  
  } else {                                  //대기
    stepCase = 0;
    radioData[2] = 0;
  }
  if(readyShotting == false) {   // 발사 준비 단계readyShotting
    checkShotting();
  } else {
    stepCase = 1;
    shottingPlaySet();
  }
}

//Shotting Ready Mode Check(처음 부팅 시)
void checkShotting() {
  if (radioData[0] == 0 && radioData[1] == 0 && radioData[2] == 0) {      // 모든 버튼 대기일 때 발사(처음 부팅 시)
    Serial.println("모든 버튼 대기일 때 발사(처음 부팅 시)");
    readyShotting = true;
    //발사 준비 확정  // led 초록색
  } else {                                                                // 모든 버튼 대기가 아닐시 발사 준비 안됨
    Serial.println("모든 버튼 대기가 아닐시 발사 준비 안됨");
    //무조건 발사 대기 할것, 스피커나 led하나 연결해서 불빛으로 상태 보여 줄 것
    //digitalWrite
    readyShotting = true; //테스트용 나중에 지워야 함. 
  }
  delay(1000);
}

//ShottingPlaySet 시작세팅
void shottingPlaySet() {
  for (int i = 0; i < 6; i++) {  //남은 총알 수 체크
    bulletCount += bulletLocation[i];
  }
  if (bulletCount > 0 && radioData[2] == 0) { // 회전모드가 대기상태이고 발사버튼이 Off 일 때
//    Serial.println("회전모드가 대기상태이고 발사버튼이 Off 일 때");
    shottingPlayMode(1);
    bulletCount = 0;
  }
  else if (bulletCount == 0 || (radioData[2] != 0 && rotationToggle == true)) { // 회전모드가 실행되고 총알 수가 없어야 함
    Serial.println("회전모드가 실행되고 총알 수가 없을 때");
    rotationToggle = true;
    shottingPlayMode(0);
    bulletCount = 0;
  } else {
//    Serial.println("총알이 있습니다");
    rotationToggle = true;
  }
}

//shottingPlay
void shottingPlayMode(int stateCase) {
  switch (stateCase) {
    case 0:                                                       //총알이 없고 회전테스트 상태거나
      if (radioData[2] == 1 && rotationToggle == true) {
        rotationTest(0);
        rotationToggle = false;
        Serial.println("시계 방향 스탭모터 회전 코드 장소 ");
      }  //시계 방향 회전
      else if (radioData[2] == 2 && rotationToggle == true) {
        rotationTest(1);  //시계 반대 방향
        rotationToggle = false;
        Serial.println("시계 반대 방향 스탭 모터 회전");
      } else {
        //Serial.println("회전테스트 대기 상태");
      }
      break;
    case 1:                                                       //총알이 있거나, 회전모드가 대기 상태이거나
   if (radioData[1] == 1 && bulletSingleToggle == false) {        //단발일 때
        if (radioData[0] == 1 && ShottingToggle == false) {       //단발상태로 발사 버튼을 누름
          ShottingToggle = true;
          shottingPlay(0);
          Serial.println("단발 발사후 상태 ");       
        } else if(radioData[0] == 0 && ShottingToggle == true) {  //단발상태로 발사 버튼을 해제
          ShottingToggle = false;
          Serial.println("단발 초기화 ");
        }
      } else if (radioData[1] == 2 && bulletMultiToggle == false){ //연발일 때
        if (radioData[0] == 1 && ShottingToggle == false) {        //연발상태로 발사 버튼을 누름
          //ShottingToggle = true;
          shottingPlay(1);
          Serial.println("연발 발사후 상태 ");
        } else {  //연발상태로 발사 버튼을 해제
          ShottingToggle = false;
          Serial.println("연발 초기화 ");
        }
      } else {                                                    //대기상태
        Serial.println("대기상태이거나 발사버튼을 해제하세요");
        if (radioData[0] == 1) {
          bulletSingleToggle = true;
          bulletMultiToggle = true;
        } else {
          bulletSingleToggle = false;
          bulletMultiToggle = false;
        }
      }
      break;
  }
}

//Shotting
void shottingPlay(int shottingCase) {  //단발 연발 발사
  switch (shottingCase) {
    case 0:                                            //단발
      for(int i = 0; i < 6; i++) {
        if (bulletLocation[i] == 1) {                //총알이 있다면
          Serial.println("단발/총알발사");
          mainMotor(1);
          bulletLocation[builletCountLocation] = 0;  //위치값에 해당하는 총알 하나 사라짐
          bulletLocation[6] --;  //총알 남은 숫자 사라짐
          builletCountLocation ++;
          if (builletCountLocation > 5) {
            builletCountLocation = 0;
          }
          Serial.print("발사 후 현재 총알 수 : ");
          Serial.println(bulletLocation[6]);
          break;
        } else if (bulletLocation[builletCountLocation] == 0) { //총알이 없다면
          Serial.println("단발/총알없어서 발사 X");
          mainMotor(0);
          builletCountLocation++;
          Serial.print("현재 총알 수 : ");
          Serial.println(bulletLocation[6]);
        }
     }
      break;
    case 1:                                           //연발
      for (int i = 0; i < 6; i++) {
        if (bulletLocation[i] == 1) {                 //총알이 있다면
          Serial.println("연발/총알발사");
          //위치값에 총알 발사
          mainMotor(1);
          bulletLocation[builletCountLocation] = 0;   //위치값에 해당하는 총알 하나 사라짐
          bulletLocation[6] --;                       //총알 남은 숫자 사라짐
          builletCountLocation ++;
          if (builletCountLocation > 5) {             //스탭모터 회전
            builletCountLocation = 0;
          }
          Serial.print("현재 총알 수 : ");
          Serial.println(bulletLocation[6]);
        } else if (bulletLocation[i] == 0) {          //위치에 총알이 없다면
          Serial.println("연발/총알없어서 발사 X");
          mainMotor(0);
          builletCountLocation ++;
          if (builletCountLocation > 5) {
            builletCountLocation = 0;
          }
          Serial.print("현재 총알 수 : ");
          Serial.println(bulletLocation[6]);
        }
      }
  }
}

//Rotation Test
void rotationTest(int rotationCase) {
  switch (rotationCase) {
    case 0:
      mainMotor(0);
      builletCountLocation++;
      if (builletCountLocation > 5) {
        builletCountLocation = 0;
      }
      Serial.print("장전 위치값 :  ");
      Serial.println(builletCountLocation);
      break;
    case 1:
      mainMotorRev();
      builletCountLocation--;
      if (builletCountLocation < 0) {
        builletCountLocation = 5;
      }
      Serial.print("장전 위치값 :  ");
      Serial.println(builletCountLocation);
      break;
  }
}

//StepMotor Case
void mainMotor(int stepCase) {                  // 정회전    //builletCountLocation   0 == 0 , 5 == 300                                           
  switch (builletCountLocation) {
    case 0:
      ShootServo();
      break;
    case 1:
      ShootServo();
      break;
    case 2:
      ShootServo();
      break;
    case 3:
      ShootServo();
      break;
    case 4:   
      ShootServo();
      break;
    case 5:  
      ShootServo();
      break;
  }
}

void ShootServo() {
//  Serial.println("스탭모터 60");
  Serial.println(stepCase);
  if (stepCase == 1) {
    FirstServoMotor(1);
    delay(500);
    stepMotor(61);
    delay(500);
    FirstServoMotor(2);
    delay(500);
    SecondServoMotor(2);
    delay(500);
    SecondServoMotor(1);
    delay(500);
  }
  else {
    stepMotor(60);
    delay(500);
  }
}

//StepMotor Case Rev
void mainMotorRev() {
  switch (builletCountLocation) {
    case 0:
      stepMotor(-60);
      delay(1000);
      break;
    case 1:
      stepMotor(-60);
      delay(1000);
      break;
    case 2:
      stepMotor(-60);
      delay(1000);
      break;
    case 3:
      stepMotor(-60);
      delay(1000);
      break;
    case 4:
      stepMotor(-60);
      delay(1000);
      break;
    case 5:
      stepMotor(-60);
      delay(1000);
      break;
  }
}

//StepMotor Oper
void stepMotor(int angle) {
  Serial.println("스탭모터");
  if(stepCount == 6) {
    Serial.println("60도 카운트 0");
    stepCount = 0;
  } else {
    Serial.println("60도 움직임");
    stepper.rotate(angle);
    stepCount++;
//    stepper.move(-MOTOR_STEPS*MICROSTEPS);
  }  
}

//ServoMotor1
void FirstServoMotor(int servoCase){
  if(servoCase == 1){
   Serial.println("서보모터1 0");
   pwm.setPWM(0, 0, 220);
  }
  else if(servoCase == 2){
   Serial.println("서보모터1 90");
   pwm.setPWM(0, 0, 300);
  }
}

//ServoMotor2
void SecondServoMotor(int servoCase) {  //서보 모터는 하나
  if(servoCase == 1){
   Serial.println("서보모터2 0");
   pwm.setPWM(12, 0, 345);
  }
  else if(servoCase == 2){
   Serial.println("서보모터2 90");
   pwm.setPWM(12, 0, 180);
  }
}
