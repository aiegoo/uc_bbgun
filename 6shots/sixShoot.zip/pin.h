//스탭 모터 
#include "BasicStepperDriver.h"

//Step
#define dirPin 11
#define stepPin 12
#define MOTOR_STEPS 800
#define RPM 10  //스탭 모터 속도 
#define MICROSTEPS 1
BasicStepperDriver stepper(MOTOR_STEPS, dirPin, stepPin);
// 서보 모터 

#include <Adafruit_PWMServoDriver.h>
#include <Wire.h>
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver();
#define SERVOMIN  150 // This is the 'minimum' pulse length count (out of 4096)
#define SERVOMAX  600 // This is the 'maximum' pulse length count (out of 4096)
#define USMIN  600 // This is the rounded 'minimum' microsecond length based on the minimum pulse of 150
#define USMAX  2400 // This is the rounded 'maximum' microsecond length based on the maximum pulse of 600
#define SERVO_FREQ 50 // Analog servos run at ~50 Hz updates

//X8R
#define shottingBullet 5 //왼족 아래 2 스위치
#define shottingMode 6  //오른쪽 3 스위치
#define shottingRotation 7  //왼쪽 위에 3 스위치
#define x8r_NoUse 8

//초기 Set
void set_ModulePin() {
  //X8R
  pinMode(shottingBullet, INPUT);
  pinMode(shottingMode, INPUT);
  pinMode(shottingRotation, INPUT);
  pinMode(x8r_NoUse, INPUT);
  
  //Step Pin
  stepper.begin(RPM, MICROSTEPS);

  pwm.begin();
  pwm.setOscillatorFrequency(27000000);
  pwm.setPWMFreq(SERVO_FREQ);  
  
  delay(10);
}
